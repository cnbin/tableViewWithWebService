//
//  ViewController.m
//  Homework
//
//  Created by Apple on 8/12/15.
//  Copyright (c) 2015 华讯网络投资有限公司. All rights reserved.
//

#import "ViewController.h"
#import "NSString+URLEncoding.h"
#define cellHeight 40

@interface ViewController ()
{
    UILabel * _bianhaoLabel;
    UILabel * _homeworkLabel;
    UILabel * _sendtimeLabel;
    UILabel * _bianhaonumLabel;
    UILabel * _homeworkContentLaebl;
    UILabel * _datatimeLabel;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.title=@"家庭作业";
    
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0,20, self.view.frame.size.width,self.view.frame.size.height)];
    _tableView.delegate =self;
    _tableView.dataSource = self;
    
    //设置分割线颜色
    [_tableView setSeparatorColor:[UIColor blackColor]];
    
    //添加等待框
    activityIndicatorView = [[UIActivityIndicatorView alloc]initWithFrame : CGRectMake(0.0f, 0.0f, 62.0f, 62.0f)];
    [activityIndicatorView setCenter: self.view.center];
    [activityIndicatorView setActivityIndicatorViewStyle: UIActivityIndicatorViewStyleGray];
    [self.view addSubview : activityIndicatorView];
    
    //开始请求
    [self startRequest];

    _titleArray=[[NSMutableArray alloc]init];
    _contentArray=[[NSMutableArray alloc]init];
    _datetimeArray=[[NSMutableArray alloc]init];
    
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell;
    NSInteger row = indexPath.row;
    cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
        for (int i=1; i<=2; i++) {
            UILabel * tempLabel=[[UILabel alloc]initWithFrame:CGRectMake((320/3.0)*i+1, 0, 0.5, 40)];
            tempLabel.backgroundColor=[UIColor blackColor];
            [cell addSubview:tempLabel];
        }
        if (row==0) {
            _bianhaoLabel=[[UILabel alloc]initWithFrame:CGRectMake(45, 5, 30, 30)];
            _bianhaoLabel.text=@"编号";
            _bianhaoLabel.font=[UIFont fontWithName:@"Helvetica" size:13];
            [cell.contentView addSubview:_bianhaoLabel];
            
            _homeworkLabel=[[UILabel alloc]initWithFrame:CGRectMake(135, 5, 60, 30)];
            _homeworkLabel.text=@"作业内容";
            _homeworkLabel.font=[UIFont fontWithName:@"Helvetica" size:13];
            [cell.contentView addSubview:_homeworkLabel];
            
            _sendtimeLabel=[[UILabel alloc]initWithFrame:CGRectMake(240, 5, 60, 30)];
            _sendtimeLabel.text=@"发送时间";
            _sendtimeLabel.font=[UIFont fontWithName:@"Helvetica" size:13];
            [cell.contentView addSubview:_sendtimeLabel];
        }
        
       
        for(int i=0;i<_titleArray.count;i++)
        {
            if(row == (i+1))
            {
                _bianhaonumLabel=[[UILabel alloc]initWithFrame:CGRectMake(55, 5, 30 ,30)];
                _bianhaonumLabel.text = [_titleArray objectAtIndex:i];
                _bianhaonumLabel.font=[UIFont fontWithName:@"Helvetica" size:13];
                [cell.contentView addSubview:_bianhaonumLabel];

                _homeworkContentLaebl=[[UILabel alloc]initWithFrame:CGRectMake(120, 5, 105, 30)];
                _homeworkContentLaebl.text =[_contentArray objectAtIndex:i];
                _homeworkContentLaebl.font=[UIFont fontWithName:@"Helvetica" size:10];
                [cell.contentView addSubview:_homeworkContentLaebl];

                _datatimeLabel=[[UILabel alloc]initWithFrame:CGRectMake(240, 5, 105, 30)];
                _datatimeLabel.text =[_datetimeArray objectAtIndex:i];
                _datatimeLabel.font=[UIFont fontWithName:@"Helvetica" size:10];
                [cell.contentView addSubview: _datatimeLabel];
            }
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return cell;
}

-(void)startRequest{
    [activityIndicatorView startAnimating];
    NSString *strURL = [[NSString alloc] initWithFormat:@"http://192.168.40.10/ReadHomework/WebService1.asmx"];
    NSURL *url = [NSURL URLWithString:[strURL URLEncodedString]];
    
    NSString * envelopeText = [NSString stringWithFormat:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"
                               "<soap:Body>"
                               "<GetTableList xmlns=\"http://tempuri.org/\" />"
                               "</soap:Body>"
                               "</soap:Envelope>"];
    
    NSData *envelope = [envelopeText dataUsingEncoding:NSUTF8StringEncoding];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:envelope];
    [request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"%d", [envelope length]] forHTTPHeaderField:@"Content-Length"];
    
    NSURLConnection *connection = [[NSURLConnection alloc]
                                   initWithRequest:request delegate:self];
    
    if (connection) {
    }
}

- (void)parserDidStartDocument:(NSXMLParser *)parser {
    //     NSLog(@"开始解析文档");
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    //      NSLog(@"结束解析文档");
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    
    //把elementName 赋值给 成员变量 currentTagName
    _currentTagName  = elementName ;
    
}

-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
     if(string!=nil)
     {
    string  = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}
    if ([string isEqualToString:@""]) {
        return;
    }
    //    NSLog(@"string is %@",string);
    
    if ([_currentTagName isEqualToString:@"Title"]) {
     
        [_titleArray addObject:string];
    }
    if([_currentTagName isEqualToString:@"Content"])
    {
     
        [_contentArray addObject:string];
    }
    if ([_currentTagName isEqualToString:@"Time"]) {
    
        [_datetimeArray addObject:string];
    }

}

#pragma mark- NSURLConnection 回调方法
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    
    NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
    parser.delegate = self;
    [parser parse];
    
}

-(void) connection:(NSURLConnection *)connection didFailWithError: (NSError *)error {
    
    NSLog(@"%@",[error localizedDescription]);
}

- (void) connectionDidFinishLoading: (NSURLConnection*) connection {
    
    NSLog(@"请求完成...");
    
    [activityIndicatorView stopAnimating];
    
     [self.view addSubview:_tableView];
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return cellHeight;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
